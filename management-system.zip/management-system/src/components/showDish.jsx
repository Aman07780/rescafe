import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useParams } from "react-router-dom";

export default function ShowDish() {
    const userString = localStorage.getItem("user");
    let user = {};
 
    if (userString) {
        user = JSON.parse(userString);
    }
    const isAdmin = user.role === 'Admin';
  const [dish, setDish] = useState([]);

  const { id } = useParams();

  useEffect(() => {
    loaddish();
  }, []);

  const loaddish = async () => {
    const result = await axios.get("http://localhost:8080/dish");
    setDish(result.data);
  };

  const deleteDish = async (id) => {
    try {
      await axios.delete(`http://localhost:8080/deletedish/${id}`);
      loaddish();
      alert("Deleted Successfully");
    } catch (error) {
      console.error("Error deleting book: ", error);
    }
  };

  return (
    <div className="container" style={{ backgroundImage: `url(${"https://img.freepik.com/free-photo/cup-hot-cappuccino-chocolate-croissant-with-breakfast_140725-9515.jpg?t=st=1714995545~exp=1714999145~hmac=7e37e07df46e7cb35ea1d3f01b0b1edd2cb94ef90f4b2a2abf61f0b612390886&w=740"})`, backgroundSize: 'cover' , height: '100vh'}}>
      <div className="py-4">
        <table className="table border shadow">
          <thead>
            <tr>
              <th scope="col">S.N</th>
              <th scope="col">DishName</th>
              <th scope="col">TypeOfDish</th>
              <th scope="col">SweetOrSavory</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
            {dish.map((dish, index) => (
              <tr>
                <th scope="row" key={index}>
                  {index + 1}
                </th>
                <td>{dish.dishName}</td>
                <td>{dish.typeOfDish}</td>
                <td>{dish.sweetOrSavory}</td>
                <td>
                  <Link
                    className="btn btn-primary mx-2"
                    to={`/viewDish/${dish.id}`}
                  >
                    View
                  </Link>
                 {isAdmin && (<>
                    <Link
                    className="btn btn-outline-primary mx-2"
                    to={`/editDish/${dish.id}`}
                  >
                    Edit
                  </Link>
                  <button
                    className="btn btn-danger mx-2"
                    onClick={() => deleteDish(dish.id)}
                  >
                    Delete
                  </button>
                 </>)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
