import axios from "axios";
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

export default function AddDish() {
  let navigate = useNavigate();

  const [dish, setDish] = useState({
    dishName: "",
    typeOfDish: "",
    sweetOrSavory: "",
  });

  const { dishName, typeOfDish, sweetOrSavory } = dish;

  const onInputChange = (e) => {
    setDish({ ...dish, [e.target.name]: e.target.value });
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:8080/dish", dish);
    alert("Added Successfully");
    navigate("/");
  };

  return (
    <div className="container" style={{ backgroundImage: `url(${"https://img.freepik.com/free-photo/cup-hot-cappuccino-chocolate-croissant-with-breakfast_140725-9515.jpg?t=st=1714995545~exp=1714999145~hmac=7e37e07df46e7cb35ea1d3f01b0b1edd2cb94ef90f4b2a2abf61f0b612390886&w=740"})`, backgroundSize: 'cover', height: '100vh' }}>
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4" style={{color:"white"}}>Add Menu</h2>

          <form onSubmit={(e) => onSubmit(e)}>
            <div className="mb-3">
              <label htmlFor="Name" className="form-label">
                DishName
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Dish name"
                name="dishName"
                value={dishName}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Username" className="form-label">
                TypeOfDish
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter Dish Type"
                name="typeOfDish"
                value={typeOfDish}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="Email" className="form-label">
              SweetOrSavory 
              </label>
              <input
                type={"text"}
                className="form-control"
                placeholder="Enter your Type"
                name="sweetOrSavory"
                value={sweetOrSavory}
                onChange={(e) => onInputChange(e)}
              />
            </div>
            <div className="d-flex align-items-center">
        <button type="submit" className="btn btn-outline-primary mr-3" style={{ width: '100px' }}>
            Submit
            </button>
           <Link className="btn btn-outline-danger mx-2" to="/" style={{ alignSelf: 'center' }}>
             Cancel
           </Link>
           </div>
          </form>
        </div>
      </div>
    </div>
  );
}
