import React from 'react'
import './About.css';
 
 
export default function About() {
  return (
    <div>
      <div class="we-are-block">
 
        <div id="about-us-section">
 
          <div class="about-us-image">
 
            <img src="https://digitalupgrade.com/images/lobbyimage_1.jpg" width="808" height="458" alt="Lobby Image" />
 
          </div>
 
          <div class="about-us-info">
 
            <h2>We are Brew Haven</h2>
 
            <p>Brew Haven is an innovative coffee management system designed to streamline your business operations and elevate your customer experience. From staff management to staff scheduling, from menu reservations to customer relationship management, Brew Haven has got you covered</p>
 
            <a href="#" title="About Us Button">ABOUT US</a>
 
          </div>
 
        </div>
 
        <div id="history-section">
 
          <div class="history-image">
 
            <img src="https://digitalupgrade.com/images/building_pic.jpg" width="951" height="471" alt="Building Pic" />
 
          </div>
 
          <div class="history-info">
 
            <h2>Our Mission</h2>
 
            <p>Our mission is to empower cafe owners and managers with a robust and user-friendly management system.We believe in the power of technology to transform the cafe industry, and we're committed to making that transformation accessible to cafes of all sizes.</p>
 
            <a href="#" title="History Button">HISTORY</a>
 
          </div>
 
        </div>
 
      </div>
    </div>
  )
}