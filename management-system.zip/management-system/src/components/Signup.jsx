import { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
 
function Signup() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("USER");
  const [name, setName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
 
  const navigate = useNavigate();
 
  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('http://localhost:8080/post/user', { email, password, role, name, phoneNumber })
      .then((res) => {
        console.log(res);
        alert("Registered successfully");
        navigate('/login');
      })
      .catch((error) => {
        console.error('There was an error!', error);
      });
  }
 
  return (
    <div class="container" style={{ marginTop: '100px' }}>
      <h1 style={{color:"white"}}>Signup</h1>
      <div className='Signup' style={{ width: '400px', margin: '0 auto' }}>
        <form onSubmit={handleSubmit}>
          <div className="input" style={{ marginBottom: '20px' }}>
            <label htmlFor="email">Email:</label>
            <input type="email" id="email" value={email} onChange={(event) => setEmail(event.target.value)} required />
          </div>
          <div className="input" style={{ marginBottom: '20px' }}>
            <label htmlFor="password">Password:</label>
            <input type="password" id="password" value={password} onChange={(event) => setPassword(event.target.value)} required />
          </div>
          <div className="input" style={{ marginBottom: '20px' }}>
            <label htmlFor="role">Role:</label>
            <input type="text" id="role" value={role} onChange={(e) => setRole(e.target.value)} required disabled />
          </div>
          <div className="input" style={{ marginBottom: '20px' }}>
            <label htmlFor="Name">FullName:</label>
            <input type="text" id="name" value={name} onChange={(event) => setName(event.target.value)} required />
          </div>
          <div className="input" style={{ marginBottom: '20px' }}>
            <label htmlFor="">phoneNumber:</label>
            <input type="text" id="phoneNumber" name="phoneNumber" value={phoneNumber} onChange={(event) => setPhoneNumber(event.target.value)} required />
          </div>
          <p>Old User? <span onClick={() => navigate('/login')} style={{color: 'blue', cursor: 'pointer'}}>Click here for Login!</span></p>
          <button type="submit" style={{ marginTop: '20px' }}>Sign Up</button>
        </form>
      </div>
    </div>
  );
};
 
export default Signup;