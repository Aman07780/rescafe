import React from 'react'
 
export default function Frontpage() {
  return (
    <div>
      <div
        className="bg-image d-flex justify-content-center align-items-center flex-column"
        style={{
          backgroundImage: "url('https://img.freepik.com/free-photo/fresh-coffee-steams-wooden-table-close-up-generative-ai_188544-8923.jpg?t=st=1714995400~exp=1714999000~hmac=959b1d705b277c7ba62599077357204b74c0f7a4065cd07da5500eb8718d1029&w=826')",
          height: "100vh",
          backgroundRepeat: "no-repeat",
          backgroundSize: "cover"
        }}
      >
        <div>
          <h1 className="text-white">Brew Haven</h1>
        </div>
        <div>
          <h4 className="text-white">Just Brew It At The Cafe</h4>
        </div>
      </div>
    </div>
  )
}