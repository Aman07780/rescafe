import React, { useState } from 'react';
import axios from 'axios';
 
const SearchDish = () => {
  const [dishName, setdishName] = useState('');
  const [dish, setdish] = useState(null);
 
 
  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.get(`http://localhost:8080/findDishByName/${dishName}`);
      setdish(response.data);
    } catch (error) {
       alert('enter a valid dish');   
      if (error.response && error.response.status === 404) {
        alert('dish not found');
      } else {
        console.error(error);
      }
    }
  };
 
  return (
    <div>
      <form onSubmit={handleSubmit}>
        <label>
          Dish Name:
          <input
            type="text"
            value={dishName}
            onChange={(e) => setdishName(e.target.value)}
          />
        </label>
        <button type="submit">Search</button>
      </form>
      {dish && (
        <div>
          <h2>{dish.dishName}</h2>
          <h3>{dish.typeOfDish}</h3>
          <p>{dish.sweetOrSavory}</p>
        </div>
      )}
    </div>
  );
};
 
export default SearchDish;