import axios from "axios";
import React, { useEffect,useState } from "react";
import { Link, useParams } from "react-router-dom";

export default function ViewDish() {
  const [dish, setDish] = useState({
    dishName: "",
    typeOfDish: "",
    sweetOrSavory: "",
  });

  const { id } = useParams();

  useEffect(() => {
    loaddishs();
  }, []);

  const loaddishs = async () => {
    const result = await axios.get(`http://localhost:8080/dish/${id}`);
    setDish(result.data);
  };

  return (
    <div className="container" style={{ backgroundImage: `url(${"https://img.freepik.com/free-photo/cup-hot-cappuccino-chocolate-croissant-with-breakfast_140725-9515.jpg?t=st=1714995545~exp=1714999145~hmac=7e37e07df46e7cb35ea1d3f01b0b1edd2cb94ef90f4b2a2abf61f0b612390886&w=740"})`, backgroundSize: 'cover' , height: '100vh'}}>
      <div className="row">
        <div className="col-md-6 offset-md-3 border rounded p-4 mt-2 shadow">
          <h2 className="text-center m-4"style={{color:"white"}}>Dish Details</h2>

          <div className="card">
            <div className="card-header">
              Details of dish id : {dish.id}
              <ul className="list-group list-group-flush">
                <li className="list-group-item">
                  <b>Dish Name:</b>
                  {dish.dishName}
                </li>
                <li className="list-group-item">
                  <b>Type Of Dish:</b>
                  {dish.typeOfDish}
                </li>
                <li className="list-group-item">
                  <b>Sweet Or Savory:</b>
                  {dish.sweetOrSavory}
                </li>
              </ul>
            </div>
          </div>
          <Link className="btn btn-primary my-2" to={"/"}>
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
}
