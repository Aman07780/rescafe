import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import Home from "./pages/Home";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import AddUser from "./users/AddUser";
import EditUser from "./users/EditUser";
import ViewUser from "./users/ViewUser";
import Frontpage from "./components/Frontpage";
import Footer from "./components/Footer";
import About from "./components/About";
import Login from "./components/Login";
import Signup from "./components/Signup";
import PrivateRoute from "./layout/PrivateRoute";
import Logout from "./components/Logout";
import SearchDish from "./components/SearchDish";
import ShowDish from "./components/showDish";
import ViewDish from "./components/ViewDishes";
import EditDish from "./components/Editdish";
import AddDish from "./components/AddDish";
function App() {
  return (
    <div className="App">
      <Router>
        <PrivateRoute />

        <Routes>
          <Route exact path="/" element={<Frontpage/>} />
          <Route exact path="/showuser" element={<Home />} />
          <Route exact path="/adduser" element={<AddUser />} />
          <Route exact path="/edituser/:id" element={<EditUser />} />
          <Route exact path="/viewuser/:id" element={<ViewUser />} />
          <Route exact path="/addDish" element={<AddDish/>} />
          <Route exact path="/showdish" element={<ShowDish/>} />
          <Route exact path="/editDish/:id" element={<EditDish/>} />
          <Route exact path="/viewDish/:id" element={<ViewDish/>} />
          
          <Route exact path="/searchDish" element={<SearchDish/>} />

          <Route exact path="/aboutus" element={<About/>} />
          <Route exact path="/login" element={<Login/>} />
          <Route exact path="/signup" element={<Signup/>} />
          <Route exact path="/logout" element={<Logout/>} />
        </Routes>
        <Footer/>
      </Router>
    </div>
  );
}

export default App;
