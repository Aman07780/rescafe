

import React from 'react';
import { Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css'; // import Bootstrap CSS
 
function Navbar() {
      // check user is Admin or not
      const userString = localStorage.getItem("user");
      let user = {};
   
      if (userString) {
          user = JSON.parse(userString);
      }
      const isAdmin = user.role === 'Admin';
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <div className="container">
        <Link to="/" className="navbar-brand">
          Brew Haven
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link to="/" className="nav-link">
                Home
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/aboutus" className="nav-link">
                About Us
              </Link>
            </li>
              {isAdmin && (<>
                <li className="nav-item">
              <Link to="/adduser" className="nav-link">
                Add Staffs
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/showuser" className="nav-link" >
               View Staffs
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/addDish" className="nav-link">
                Add Menu
              </Link>
            </li>
              </>)}
            <li className="nav-item">
              <Link to="/showDish" className="nav-link">
                View Menu
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/searchDish" className="nav-link">
                Search Menu
              </Link>
              </li>
          </ul>
          <ul className="navbar-nav ms-auto">
            {/* <li className="nav-item">
              <Link to="/signup" className="nav-link">
                Sign Up
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/login" className="nav-link">
                Log In
              </Link>
            </li> */}
            
            <li className="nav-item">
              <Link to="/logout" className="nav-link">
                Logout
              </Link>
             
              
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}
 
export default Navbar;